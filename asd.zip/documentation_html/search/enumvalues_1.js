var searchData=
[
  ['bought_0',['bought',['../_ticket_8h.html#ae4ad5c9a1b71b87331ca7c0cd486446da71228d08e010a6bb1e3a19643684204e',1,'Ticket.h']]]
];
