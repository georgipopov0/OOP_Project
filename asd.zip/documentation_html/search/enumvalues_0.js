var searchData=
[
  ['available_0',['available',['../_ticket_8h.html#ae4ad5c9a1b71b87331ca7c0cd486446da5d20e160566f0b85357fd5a3c87a985e',1,'Ticket.h']]]
];
