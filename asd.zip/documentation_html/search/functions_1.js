var searchData=
[
  ['boughtticket_0',['BoughtTicket',['../class_bought_ticket.html#a76f0441e4870617f5dd75b0a33e0c2c0',1,'BoughtTicket::BoughtTicket()'],['../class_bought_ticket.html#a00038917d7f73fd9b9b70071f5283553',1,'BoughtTicket::BoughtTicket(Ticket)']]],
  ['buyticket_1',['BuyTicket',['../class_performance.html#aa1ca33df8af3c8df34d6ee758284dfbf',1,'Performance::BuyTicket()'],['../class_ticket_office.html#a5584e4827a25cfa69fa58920a148d260',1,'TicketOffice::BuyTicket()']]]
];
