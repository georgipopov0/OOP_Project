var searchData=
[
  ['addhall_0',['addHall',['../class_ticket_office.html#ac3987bc62c42619289eb2a661fa80d76',1,'TicketOffice']]],
  ['addperformence_1',['addPerformence',['../class_hall.html#a1692174a62734974555c22e1961299c3',1,'Hall::addPerformence()'],['../class_ticket_office.html#a8ac594e8709eb86e1612f237c9d6aa24',1,'TicketOffice::addPerformence()']]],
  ['available_2',['available',['../_ticket_8h.html#ae4ad5c9a1b71b87331ca7c0cd486446da5d20e160566f0b85357fd5a3c87a985e',1,'Ticket.h']]]
];
