var searchData=
[
  ['seat_0',['seat',['../class_ticket.html#a0e721f9d14e04471b65264c22403b202',1,'Ticket']]],
  ['size_1',['size',['../class_vector.html#a196e9eedc9a88a48f64e69e39405fa72',1,'Vector']]]
];
