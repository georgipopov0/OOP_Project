var searchData=
[
  ['init_0',['init',['../class_controller.html#a9904f7fc1d538558a197157c24d69478',1,'Controller']]]
];
