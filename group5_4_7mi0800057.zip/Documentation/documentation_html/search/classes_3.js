var searchData=
[
  ['mystring_0',['myString',['../classmy_string.html',1,'']]]
];
