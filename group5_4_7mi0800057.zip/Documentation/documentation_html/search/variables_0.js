var searchData=
[
  ['roll_0',['roll',['../class_ticket.html#aa07914b3b4ff1029ea4e2ba0b50bd6d8',1,'Ticket']]]
];
