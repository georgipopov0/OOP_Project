var searchData=
[
  ['reserved_0',['reserved',['../_ticket_8h.html#ae4ad5c9a1b71b87331ca7c0cd486446dac6638028c1aba75eca7eed225800ad5b',1,'Ticket.h']]]
];
